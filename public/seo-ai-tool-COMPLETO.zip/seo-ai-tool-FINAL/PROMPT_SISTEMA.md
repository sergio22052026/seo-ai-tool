# SEO AI Analyzer — Prompt di Sistema Completo
*Salva questo file per riprendere lo sviluppo in futuro*

---

## CONTESTO DEL PROGETTO

**Tool**: SEO AI Analyzer — strumento interno per agenti di vendita Italia Online  
**URL produzione**: https://seo-ai-tool-61no.onrender.com  
**GitHub**: sergio22052026/seo-ai-tool (branch main)  
**Stack**: Node.js + Express (server.js) + HTML/CSS/JS puro (public/index.html) + comuni.js  
**Deploy**: Render.com (Manual Deploy dal branch main)

---

## CREDENZIALI

- Password agenti: `agentiace2026`
- Password admin: `Nigilek1969@fuck`
- Variabili Render: `ANTHROPIC_API_KEY`, `ADMIN_PASSWORD`, `ACCESS_PASSWORD`

---

## ARCHITETTURA FILE

```
seo-ai-tool/
├── server.js          — Express backend, sessioni, endpoint API
├── package.json       — dipendenze Node.js
└── public/
    ├── index.html     — tutta la UI (HTML + CSS + JS in un file)
    └── comuni.js      — dati geografici Italia (province, comuni, regioni, coordinate)
```

---

## STRUTTURA APPLICAZIONE

### Backend (server.js)
- `POST /api/login` / `POST /api/admin/login` / `POST /api/logout`
- `POST /api/check-site` — verifica raggiungibilità URL
- `POST /api/suggest` — step 1: suggerisce keyword e competitor
- `POST /api/analyze` — step 2: analisi SEO completa
- Modello Claude: `claude-sonnet-4-5`, max_tokens: 8000
- Sessioni in-memory 8h

### Frontend (index.html)
**Librerie esterne**:
- Chart.js 4.4.1 (grafici trend e AI rank)
- jsPDF 2.5.1 (export PDF)
- Tabler Icons 3.0.0 (icone)
- Leaflet 1.9.4 (rimosso nella versione corrente)

**Variabili globali chiave**:
```js
let token, userRole, geoSelectedAreas=[], currentData=null
let suggestData=null, selectedKws=[], selectedComps=[]
let trendCharts=[], aiChartInst=null, bizType='b2c'
```

---

## FLUSSO UTENTE

### Step 1 — Form
1. Sito web (con verifica raggiungibilità + link Maps + link sito)
2. Settore ATECO (ricerca testuale)
3. **Regione** → Provincia → Comune (cascata, dati da comuni.js)
4. Tipo azienda: B2C / B2B / Entrambe
5. Rilevanza geografica: Comunale / Provinciale / Regionale / Nazionale / Internazionale
6. **Selezione comuni per keyword** (checkbox, filtrati per rilevanza)
7. Numero keyword (1-15, il tool ne suggerisce il doppio)

### Step 2 — Selezione keyword e competitor
- Lista keyword suggerite (doppio del richiesto)
- Lista competitor suggeriti (filtrati per B2B/B2C)
- Aggiunta manuale keyword e competitor

### Step 3 — Report (15 sezioni)
**Prima riga tab**: Keyword · Trends · Visibilità AI · SEO · Social · GBP · Competitor · Confronto · Score card  
**Seconda riga tab**: Consigli migliorativi · Opportunità · Piano d'azione · Proposta · Strumenti

---

## SEZIONI REPORT

| Tab | ID pannello | Funzione render | Contenuto |
|-----|-------------|-----------------|-----------|
| Keyword | p-kw | renderResults | tabella kw con vol/CPC/comp/AI rank/trend |
| Trends | p-trends | renderResults | grafici Chart.js 12 mesi |
| Visibilità AI | p-ai | renderResults | barre + descrizioni verticali per keyword |
| SEO | p-dim | renderResults | 6 dimensioni con barre |
| Social | p-social | renderResults | card social con SVG logo |
| GBP | p-gbp | renderResults | punteggio + link Maps |
| Competitor | p-comp | renderResults | card competitor |
| Confronto | p-compare | renderCompare | tabella sticky, solo competitor con dati |
| Score card | p-scorecard | renderScoreCard | gauge SVG + 4 card + dettaglio SEO |
| Consigli migliorativi | p-consigli | renderResults | quick wins + raccomandazioni unificati |
| Opportunità | p-opportunita | renderOpportunity | fatturato perso + calcolatore ticket |
| Piano d'azione | p-piano | renderRoadmap | azioni strutturate senza timing/fasi |
| Proposta | p-proposta | renderProposal | testo commerciale con servizi ItaliaOnline |
| Strumenti | p-links | renderResults | link utili (GSC, Analytics, SEMrush...) |

---

## LOGICA GEOGRAFICA KEYWORD

```
Comunale  → keyword con nome comune sede (es. "infissi Jesi")
Provinciale → keyword con comuni principali della provincia
Regionale → keyword con comuni principali della regione  
Nazionale → keyword senza geolocalizzazione
```

**Server prompt geo**:
- Se geoAreas selezionati → keyword specifiche per ogni comune selezionato
- Se nazionale → nessuna geo nelle keyword
- Competitor: sempre almeno regionali come minimo, filtrati per B2B/B2C

---

## DATI GEOGRAFICI (comuni.js)

```js
const PROVINCE    // Array {c: codice, n: nome} — 107 province
const COMUNI      // Object {codice: [array comuni]} — tutti i comuni italiani
const CATEGORIE   // Array {cod, label} — categorie ATECO Camera di Commercio
const PROVINCE_COORDS  // Object {codice: [lat, lng]} — capoluoghi
const COMUNI_COORDS    // Object {nome: [lat, lng]} — comuni principali
function getComuniCoords(provCode, comuni) // genera coords approssimative
function getComuneCoord(name) // coords reali se disponibili
```

---

## SISTEMA TOOLTIP "i"

- CSS: `.tt-b{opacity:0;pointer-events:none;position:fixed;top:-9999px;}`
- CSS: `.tt-b.visible{opacity:1!important;pointer-events:auto}`
- JS: `initTooltips(root)` — usa `dataset.ttInited` per evitare duplicati
- **Trigger: mouseenter** (non click)
- **Hide: mouseleave** dal .tt-wrap
- Posizionamento: fixed calcolato da viewport, mai fuori schermo
- Chiamato dopo ogni render dinamico con `setTimeout(()=>initTooltips(),200)`

---

## TOPBAR PULSANTI (sinistra→destra)

1. Logo + ruolo
2. Admin (nascosto per agenti)
3. **Nuova analisi** (verde, visibile solo con report attivo)
4. **Esporta PDF** (arancione, visibile solo con report attivo)
5. **Restart** (ambra) — logout + clear storage + reload
6. **Esci** — logout

---

## SEZIONE PROPOSTA COMMERCIALE

Riferisce ai servizi ItaliaOnline:
1. Sito web professionale (SEO-ready)
2. Local SEO & Google Business Profile
3. AI Visibility Optimization (ChatGPT, Perplexity, Gemini)
4. Campagne Google Ads geolocalizzate
5. Social Media Management
6. Reportistica & Monitoraggio mensile

---

## STORICO ANALISI

- `localStorage` key: `seo_history`, max 100 voci
- Filtri: Tutte / Ultimo mese / Ultima settimana / Nessuna
- Click su voce → ricarica report completo

---

## AUTENTICAZIONE

- Token in `sessionStorage` ('seo_token', 'seo_role')
- Sessioni 8h, pulizia automatica ogni ora
- **Restart**: logout + `sessionStorage.clear()` + `localStorage.clear()` + `reload(true)`

---

## BUG RICORRENTI E SOLUZIONI

### 1. Apostrofi italiani nel JS
**Problema**: parole come `dell'`, `l'`, `un'`, `all'` dentro stringhe JS single-quoted causano SyntaxError  
**Fix**: script Python che fa escape di tutti gli apostrofi italiani nelle righe con numero dispari di `'`  
```python
italian_apos = ["dell'", "l'", "un'", "all'", "nell'", "sull'", "dall'", "c'è"]
for word in italian_apos:
    escaped = word.replace("'", "\\'")
    line = line.replace(word, escaped)
```

### 2. Variabili globali dichiarate due volte
**Problema**: `let geoMap`, `let token` ecc. dichiarate in più blocchi JS  
**Fix**: cercare con regex tutti i `let/const/var nome` e rimuovere i duplicati  

### 3. HTML/JS che "esce" dallo script tag
**Problema**: template literal backtick con contenuto lungo può chiudersi prematuramente  
**Fix**: usare concatenazione di stringhe invece di template literal nelle funzioni di render complesse  

### 4. File HTML duplicato
**Problema**: sostituzioni sbagliate possono duplicare l'intero HTML  
**Fix**: verificare sempre `html.count('<body')` == 1 e `html.count('id="step-form"')` == 1  

### 5. comuni.js caricato due volte
**Problema**: `PROVINCE already declared` — `comuni.js` incluso due volte nel head  
**Fix**: verificare `html.count('comuni.js')` == 1  

---

## PROCEDURA DEPLOY

1. Aggiorna i 4 file su GitHub: `server.js`, `package.json`, `public/index.html`, `public/comuni.js`
2. Render → Manual Deploy
3. Attendi "Your service is live" (2-3 minuti)
4. Usa pulsante **Restart** per svuotare cache browser prima di testare

---

## VERIFICA RAPIDA PRIMA DEL DEPLOY

```python
# Checklist da eseguire prima di ogni zip/deploy
checks = {
    'body unico': html.count('<body') == 1,
    'step-form unico': html.count('id="step-form"') == 1,
    'step-select unico': html.count('id="step-select"') == 1,
    'comuni.js unico': html.count('comuni.js') == 1,
    'agent-pwd unico': html.count('id="agent-pwd"') == 1,
    'zero JS issues': len(problems) == 0,
    'agentLogin': 'function agentLogin' in all_js,
    'renderResults': 'function renderResults' in all_js,
    'getReg': 'function getReg' in all_js,
    'runSuggest': 'async function runSuggest' in all_js,
}
```

---

## PROMPT PER NUOVA SESSIONE

Quando inizi una nuova conversazione con Claude, usa questo prompt:

```
Sto lavorando su un tool SEO AI per agenti di vendita Italia Online.
URL produzione: https://seo-ai-tool-61no.onrender.com
GitHub: sergio22052026/seo-ai-tool

Stack: Node.js + Express (server.js) + HTML/CSS/JS puro (index.html) + comuni.js (dati geografici Italia)

Il tool permette agli agenti di analizzare la presenza digitale di un'azienda:
1. Inserisci sito, settore ATECO, regione/provincia/comune, tipo azienda (B2C/B2B), rilevanza geografica
2. Selezioni keyword e competitor tra quelli suggeriti da Claude
3. Ottieni un report con 14 sezioni: keyword, trends, visibilità AI, SEO, social, GBP, competitor, confronto, score card, consigli migliorativi, opportunità, piano d'azione, proposta (con servizi ItaliaOnline), strumenti

Ti carico i file attuali e ti chiedo le modifiche specifiche.

REGOLE IMPORTANTI:
- Dopo ogni modifica, controlla apostrofi italiani nei JS (dell', l', un', all' ecc.)
- Verifica sempre che: body=1, step-form=1, agent-pwd=1, comuni.js=1
- Usa concatenazione stringhe nelle funzioni render, non template literal per testi lunghi
- Crea sempre lo zip con tutti e 4 i file: server.js, package.json, public/index.html, public/comuni.js
```
